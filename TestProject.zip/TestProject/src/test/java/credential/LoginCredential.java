package credential;

public class LoginCredential {
    public String base_url="https://binsight.streamstech.com/";
    public String loginemail="qa";
    public String loginpassword="123";
}
